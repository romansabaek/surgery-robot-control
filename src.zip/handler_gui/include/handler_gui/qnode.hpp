/**
 * @file /include/handler_gui/qnode.hpp
 *
 * @brief Communications central!
 *
 * @date February 2011
 **/
/*****************************************************************************
** Ifdefs
*****************************************************************************/

#ifndef handler_gui_QNODE_HPP_
#define handler_gui_QNODE_HPP_

/*****************************************************************************
** Includes
*****************************************************************************/

#include <ros/ros.h>
#include <string>
#include <QThread>
#include <QStringListModel>
#include "../include/kaist/dynamixel_msg.h"
#include "../include/kaist/motion.h"
#include "../include/kaist/gui_msg.h"
//#include "../handler_gui/qcustomplot.h"
/*****************************************************************************
** Namespaces
*****************************************************************************/

namespace handler_gui {

/*****************************************************************************
** Class
*****************************************************************************/

class QNode : public QThread {
    Q_OBJECT
public:
	QNode(int argc, char** argv );
	virtual ~QNode();
	bool init();
	//bool init(const std::string &master_url, const std::string &host_url);
	void run();

	/*********************
	** Logging
	**********************/
	enum LogLevel {
	         Debug,
	         Info,
	         Warn,
	         Error,
	         Fatal
	 };

    int ID[4];
    int Velocity[4];
    int Position[4];
    double Current[4];
    int Translation_length;

	QStringListModel* loggingModel() { return &logging_model; }
	void log( const LogLevel &level, const std::string &msg);

Q_SIGNALS:
	void loggingUpdated();
    void rosShutdown();
	void updateStatus();
private:
	int init_argc;
	char** init_argv;
    void ReadData(const kaist::gui_msg::ConstPtr& msg);

    	QStringListModel logging_model;
};

}  // namespace handler_gui

#endif /* handler_gui_QNODE_HPP_ */
