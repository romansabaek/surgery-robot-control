/**
 * @file /include/handler_gui/main_window.hpp
 *
 * @brief Qt based gui for handler_gui.
 *
 * @date November 2010
 **/
#ifndef handler_gui_MAIN_WINDOW_H
#define handler_gui_MAIN_WINDOW_H

/*****************************************************************************
** Includes
*****************************************************************************/

#include <QtGui/QMainWindow>
#include <QDebug>
#include <QtGui>
#include <QPainter>
#include <QGraphicsItem>
#include <QMessageBox>
#include <iostream>
#include <QTimer>
#include "ui_main_window.h"
#include "qnode.hpp"
#include "ros/ros.h"
//#include "../handler_gui/qcustomplot.h"

/*****************************************************************************
** Namespace
*****************************************************************************/

namespace handler_gui {

/*****************************************************************************
** Interface [MainWindow]
*****************************************************************************/
/**
 * @brief Qt central, all operations relating to the view part here.
 */
class MainWindow : public QMainWindow {
Q_OBJECT

public:
	MainWindow(int argc, char** argv, QWidget *parent = 0);
	~MainWindow();

    void closeEvent(QCloseEvent *event);

private Q_SLOTS:
	/******************************************
	** Auto-connections (connectSlotsByName())
	*******************************************/
        void update();

        void on_Windowclose_clicked();

    	void on_Initializebutton_clicked();
    
    	void on_ENDbutton_clicked();
    
    	void on_TorqueOnbutton_clicked();
    
    	void on_TorqueOffbutton_clicked();


    /******************************************
    ** Manual connections
    *******************************************/
    //void updateLoggingView(); // no idea why this can't connect automatically

        void on_STARTbutton_clicked();

        void on_sendbutton_clicked();

        void on_STOPbutton_clicked();

        void on_automode_clicked();

        void on_MenuMode_clicked();

        void on_Offsetbutton_clicked();

        void on_joint_clicked();

        void on_speed_clicked();

private:
	Ui::MainWindow ui;
    QTimer *timer;
	QTextEdit *text();
    QGraphicsScene *scene;
    QGraphicsLineItem *line[41+21+1];
    QPen pen_ora, pen_yel,pen_blk;
	QNode qnode;

};

}  // namespace handler_gui

#endif // handler_gui_MAIN_WINDOW_H
