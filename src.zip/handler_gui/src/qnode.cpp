/*==============================================================================
 *
 *   handler_gui
 *
 *   	File Name   	: qnode.cpp
 *  	Version        	: 1.0
 *    	Date           	: July 11, 2016 ~
 *		Author         	: BaekDongHoon
 *		work        	: ros GUI
 *		Compiler		: catkin
 *    	All Rights Reserved.
 *
==============================================================================*/

/*****************************************************************************
** Includes
*****************************************************************************/

#include <ros/ros.h>
#include <ros/network.h>
#include <QtGui>
#include <QMessageBox>
#include <string>
#include <std_msgs/String.h>
#include <sstream>
#include <vector>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <termios.h>
#include <getopt.h>
#include <fcntl.h>
#include "../include/handler_gui/qnode.hpp"
#include "../include/kaist/dynamixel_msg.h"
#include "../include/kaist/motion.h"
#include "../include/handler_gui/main_window.hpp"
//#include "../include/handler_gui/qcustomplot.h"

/*****************************************************************************
** Namespaces
*****************************************************************************/
#define PKT_RTN_DELAY_US	5000
#define CONTROL_PERIOD		10000

#define Left   1
#define Right  2
#define Up     3
#define Down   4
#define Rotation_L 5
#define Rotation_R 6
#define STOP   7
#define Rotation_on 8

#define key_OFFSET 23

namespace handler_gui {

/*****************************************************************************
** Implementation
*****************************************************************************/

ros::Publisher gui_pub;
ros::Subscriber gui_sub;


QNode::QNode(int argc, char** argv ) :
	init_argc(argc),
	init_argv(argv)
	{}

QNode::~QNode() {
    if(ros::isStarted()) {
      ros::shutdown(); // explicitly needed since we use ros::start();
      ros::waitForShutdown();
    }
	wait();
}


void QNode::ReadData(const kaist::gui_msg::ConstPtr& msg)
{

    if(msg->key == Up || msg->key == Down)
    {
        for(int i=0; i<msg->id.size(); i++ )
        {
            //speed
            if(msg->key==Up)
            {
                Velocity[0] = (msg->Moving_speed[i]) - 1000;
                if(msg->Moving_speed[i] <1000) Velocity[0] = msg->Moving_speed[i];
            }
            else Velocity[0] = msg->Moving_speed[i];
            //position
            Position[0] = msg->Goal_position[i];
            Current[0] = msg->Current[i];
        }
    }
    if(msg->key == Right || msg->key == Left)
    {
        for(int i=0; i<msg->id.size(); i++ )
        {
            if(msg->key==Left)
            {
                Velocity[1] = msg->Moving_speed[i]-1000;
                if(msg->Moving_speed[i] <1000) Velocity[1] = msg->Moving_speed[i];
            }
            else Velocity[1] = msg->Moving_speed[i];
            Position[1] = msg->Goal_position[i];
            Current[1] = msg->Current[i];
        }
    }
    if(msg->key == Rotation_L || msg->key == Rotation_R)
    {
        for(int i=0; i<msg->id.size(); i++ )
        {
            if(msg->key==Rotation_L)
            {
                Velocity[2] = (msg->Moving_speed[i]) - 1000;
                if(msg->Moving_speed[i] <1000) Velocity[2] = msg->Moving_speed[i];
            }
            else Velocity[2] = msg->Moving_speed[i];
            Position[2] = msg->Goal_position[i];
            Current[2] = msg->Current[i];
        }
    }

    //motion callback
    if(msg->key == key_OFFSET)
    {
        for(int i=0; i<msg->id.size(); i++ )
        {
            Velocity[i] = msg->Moving_speed[i];
            Position[i] = msg->Goal_position[i];
            Current[i]  = msg->Current[i];
        }
    }

    Q_EMIT updateStatus();
}


bool QNode::init() {
	ros::init(init_argc,init_argv,"handler_gui");
	if ( ! ros::master::check() ) {
		return false;
	}
	ros::start(); // explicitly needed since our nodehandle is going out of scope.
	ros::NodeHandle nh;

    gui_pub = nh.advertise<kaist::motion>("motion",100);
    gui_sub = nh.subscribe<kaist::gui_msg>("gui",100,&QNode::ReadData,this);

    Translation_length = 30;
    for(int i=0;i<3;i++)
    {
        Velocity[i] = 0;
        Position[i] = 0;
    }
    // Add your ros communications here.
	
	start();
	return true;
}


void QNode::run() {

	while ( ros::ok() ){

	ros::spinOnce();		
	}	
}


void QNode::log( const LogLevel &level, const std::string &msg) {
	logging_model.insertRows(logging_model.rowCount(),1);
	std::stringstream logging_model_msg;
	switch ( level ) {
		case(Debug) : {
				ROS_DEBUG_STREAM(msg);
				logging_model_msg << "[DEBUG] [" << ros::Time::now() << "]: " << msg;
				break;
		}
		case(Info) : {
				ROS_INFO_STREAM(msg);
				logging_model_msg << "[INFO] [" << ros::Time::now() << "]: " << msg;
				break;
		}
		case(Warn) : {
				ROS_WARN_STREAM(msg);
				logging_model_msg << "[INFO] [" << ros::Time::now() << "]: " << msg;
				break;
		}
		case(Error) : {
				ROS_ERROR_STREAM(msg);
				logging_model_msg << "[ERROR] [" << ros::Time::now() << "]: " << msg;
				break;
		}
		case(Fatal) : {
				ROS_FATAL_STREAM(msg);
				logging_model_msg << "[FATAL] [" << ros::Time::now() << "]: " << msg;
				break;
		}
	}
	QVariant new_row(QString(logging_model_msg.str().c_str()));
	logging_model.setData(logging_model.index(logging_model.rowCount()-1),new_row);
	Q_EMIT loggingUpdated(); // used to readjust the scrollbar
}

}  // namespace handler_gui
