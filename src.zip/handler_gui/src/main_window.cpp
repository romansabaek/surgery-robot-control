/*==============================================================================
 *
 *   handler_gui
 *
 *   	File Name   	: main_window.cpp
 *  	Version        	: 1.0
 *    	Date           	: July 11, 2016 ~
 *		Author         	: BaekDongHoon
 *		work        	: GUI
 *		Compiler		: catkin
 *    	All Rights Reserved.
 *
==============================================================================*/
/*****************************************************************************
** Includes
*****************************************************************************/

#include <QtGui>
#include <QtDebug>
#include <QtCore>
#include <QMessageBox>
#include <QApplication>
#include <iostream>
#include <vector>
#include "stdio.h"
#include <sstream>
#include <iostream>
#include <math.h>
#include <stdlib.h>
#include <unistd.h>
#include <termios.h>
#include <getopt.h>
#include <fcntl.h>
#include "../include/handler_gui/main_window.hpp"
#include "../include/handler_gui/qnode.hpp"
#include "../include/kaist/dynamixel_msg.h"
#include "../include/kaist/motion.h"
#include "../include/kaist/gui_msg.h"
//#include "../include/handler_gui/qcustomplot.h"

/*****************************************************************************
** Namespaces
*****************************************************************************/
#define PKT_RTN_DELAY_US	5000
#define CONTROL_PERIOD		10000

//Handler parameter
#define L1  (double)23.5
#define L2  150
#define L3  282
#define d   200 //115-275
#define POINT 62

//math
#define PI			(double)(3.14159265358979323846)
#define GRAVITY		(double)(9.81)
#define DTR(x)		(double)((double)(x) * PI / 180.0)	// degree to radian
#define RTD(x)		(double)((double)(x) * 180.0 / PI)	// radian to degree

//parameter
bool Automode = false;
int Data_speed[4] = {0,};
bool START_KEY = false;

namespace handler_gui {

extern ros::Publisher gui_pub;
extern ros::Subscriber gui_sub;
extern int Velocity[4];
extern int Position[4];
extern int Translation_length;

using namespace Qt;

/*****************************************************************************
** Implementation [MainWindow]
*****************************************************************************/

MainWindow::MainWindow(int argc, char** argv, QWidget *parent)
	: QMainWindow(parent)
	, qnode(argc,argv)
{
	ui.setupUi(this); // Calling this incidentally connects all ui's triggers to on_...() callbacks in this class.
    //QObject::connect(ui.actionAbout_Qt, SIGNAL(triggered(bool)), qApp, SLOT(aboutQt())); // qApp is a global variable for the application

    QTimer *timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(update()));
    timer->start(50);



        //draw background
        scene = new QGraphicsScene(this);
        //QPixmap pim("/home/baekdonghoon/catkin_ws/src/handler_gui/resources/images/1.png");
        //scene->setBackgroundBrush(pim.scaled(500,200,Qt::IgnoreAspectRatio,Qt::SmoothTransformation));
        //ui.status->fitInView(scene->sceneRect(),Qt::KeepAspectRatio);

        ////draw///////////
        pen_ora.setColor(QColor(255,94,0));
        pen_ora.setWidth(2);
        pen_yel.setColor(QColor(255,187,0));
        pen_yel.setWidth(8);
        pen_blk.setColor(Qt::black);
        pen_blk.setWidth(1);


        // -20cm ~ 20cm : y
        for(int i=0;i<41;i++) //41 line
        {
            line[i] = new QGraphicsLineItem(-200+(i*10),100,-200+(i*10),-100);
            line[i]->setPen(pen_blk);
            line[20] = new QGraphicsLineItem(0,100,0,-100);
            line[20]->setPen(pen_ora);
            scene->addItem(line[i]);
        }
        for(int i=41;i<62;i++) //21 line
        {
            line[i] = new QGraphicsLineItem(200,-100+((i-41)*10),-200,-100+((i-41)*10));
            line[i]->setPen(pen_blk);
            line[51] = new QGraphicsLineItem(200,0,-200,0);
            line[51]->setPen(pen_ora);
            scene->addItem(line[i]);
        }

        line[POINT] = new QGraphicsLineItem(0,-50,0,0);
        line[POINT]->setPen(pen_yel);
        scene->addItem(line[POINT]);
        ui.status->setScene(scene);

    QObject::connect(&qnode, SIGNAL(rosShutdown()), this, SLOT(close()));
    QObject::connect(&qnode, SIGNAL(updateStatus()), this, SLOT(update()));
    //QObject::connect(&qnode, SIGNAL(updateImage()), this, SLOT(imageViewUpdate()));

    //TAP
    //ui.Joystick->setTitle("newTitle");

    //line edit Init
    ui.T_speed_id1->setText(QString::number(0.0));
    ui.T_speed_id2->setText(QString::number(0.0));
    ui.T_speed_id3->setText(QString::number(0.0));
    ui.T_speed_id4->setText(QString::number(0.0));
    ui.C_speed_id1->setText(QString::number(0.0));
    ui.C_speed_id2->setText(QString::number(0.0));
    ui.C_speed_id3->setText(QString::number(0.0));
    ui.C_speed_id4->setText(QString::number(0.0));

    ui.C_posi_id1->setText(QString::number(0.0));
    ui.C_posi_id2->setText(QString::number(0.0));
    ui.C_posi_id3->setText(QString::number(0.0));
    ui.C_posi_id4->setText(QString::number(0.0));
    ui.C_angle_id1->setText(QString::number(0.0));
    ui.C_angle_id2->setText(QString::number(0.0));
    ui.C_angle_id3->setText(QString::number(0.0));
    ui.C_angle_id4->setText(QString::number(0.0));

    ui.T_X->setText(QString::number(0.0));
    ui.T_Y->setText(QString::number(0.0));
    ui.T_Z->setText(QString::number(0.0));
    ui.C_X->setText(QString::number(0.0));
    ui.C_Y->setText(QString::number(0.0));
    ui.C_Z->setText(QString::number(0.0));

    ui.dial_roll->setValue(0);
    ui.dial_pitch->setValue(0);
    ui.dial_rotation->setValue(0);
    ui.dial_translation->setValue(0);

    ui.hori_roll->setValue(0);
    ui.hori_pitch->setValue(0);
    ui.hori_rotation->setValue(0);
    ui.hori_translation->setValue(0);


    ui.Current1->setValue(0);
    ui.Current2->setValue(0);
    ui.Current3->setValue(0);
    ui.Current4->setValue(0);

    ui.Current1->setMinimum(-1);
    ui.Current1->setMaximum(1);
    ui.Current2->setMinimum(-1);
    ui.Current2->setMaximum(1);
    ui.Current3->setMinimum(-1);
    ui.Current3->setMaximum(1);
    ui.Current4->setMinimum(-1);
    ui.Current4->setMaximum(1);
    qnode.init();
}

MainWindow::~MainWindow() {}




void MainWindow::update()
{
    double C_theta[2] = {0,};
    float Theta[2] = {0,};
    float x,y,z;

    //information
    ui.C_speed_id1->setText(QString::number(qnode.Velocity[0]));
    ui.C_speed_id2->setText(QString::number(qnode.Velocity[1]));
    ui.C_speed_id3->setText(QString::number(qnode.Velocity[2]));
    ui.C_speed_id4->setText(QString::number(qnode.Velocity[3]));

    ui.C_posi_id1->setText(QString::number(qnode.Position[0])); //pitch 1800 ~ 2480 (2048 center)
    ui.C_posi_id2->setText(QString::number(qnode.Position[1]));  //roll 2000 ~ 2660 (2330 center)
    ui.C_posi_id3->setText(QString::number(qnode.Position[2]));
    ui.C_posi_id4->setText(QString::number(qnode.Position[3]));

    ui.dial_roll->setValue(qnode.Position[1]);
    ui.dial_pitch->setValue(qnode.Position[0]);
    ui.dial_rotation->setValue(qnode.Position[2]);
    ui.dial_translation->setValue(qnode.Position[3]);

    ui.hori_roll->setValue(qnode.Position[1]);
    ui.hori_pitch->setValue(qnode.Position[0]);
    ui.hori_rotation->setValue(qnode.Position[2]);
    ui.hori_translation->setValue(qnode.Position[3]);

    ui.Current1->setValue(double(qnode.Current[0]));
    ui.Current2->setValue(double(qnode.Current[1]));
    ui.Current3->setValue(double(qnode.Current[2]));
    ui.Current4->setValue(double(qnode.Current[3]));

    if(qnode.Position[0]>=2048) C_theta[0] =  abs(qnode.Position[0] - 2048) *360/4096;
    else if(qnode.Position[0]<2048)C_theta[0] =  -abs(qnode.Position[0] - 2048) *360/4096;

    if(qnode.Position[1]>=2330) C_theta[1] =  abs(qnode.Position[1] - 2330) *360/4096;
    else if(qnode.Position[1]<2330) C_theta[1] =  -abs(qnode.Position[1] - 2330) *360/4096;

    ui.C_angle_id1->setText(QString::number(C_theta[0]));
    ui.C_angle_id2->setText(QString::number(C_theta[1]));

    //graphic view//
    if(qnode.Position[0]>=2048) Theta[0] = DTR(abs(qnode.Position[0] - 2048) *360/4096);
    else if(qnode.Position[0]<2048) Theta[0] = - DTR(abs(qnode.Position[0] - 2048) *360/4096);
    if(qnode.Position[1]>=2330) Theta[1] = DTR(abs(qnode.Position[1] - 2330) *360/4096);
    else if(qnode.Position[1]<2330) Theta[1] = - DTR(abs(qnode.Position[1] - 2330) *360/4096);


    x = -(d-L2) * cos(Theta[1]) * cos(Theta[0]);
    y = -(d-L2) * cos(Theta[0]) * sin(Theta[1]);
    z = L3 + sin(Theta[0]) * (d-L2);

    ui.C_Y->setText(QString::number(y));
    ui.C_X->setText(QString::number(x));
    ui.C_Z->setText(QString::number(z));
    //POINT UPDATE
    line[POINT]->setLine(0,0,-y,-x); //x1 ,y1, x2, y2
}

void MainWindow::closeEvent(QCloseEvent *event)
{
    QMainWindow::closeEvent(event);

}



///////////////////////////////////////////////////////////////////buttons////////////////////////////////////
/// //////////////////////////////////////////////////////////////////////////////////////////////////////////
void MainWindow::on_Windowclose_clicked()
{
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this,"Stop system","Are you sure??",QMessageBox::Yes|QMessageBox::No);

    if(reply == QMessageBox::Yes)
    {
        this->close();
        ui.StatusCheck->insertPlainText(" Window Close!!\n");
        ui.StatusCheck->moveCursor(QTextCursor::End);
    }
    else if(reply == QMessageBox::No)
    {
        ui.StatusCheck->insertPlainText(" Keep this!!\n");
        ui.StatusCheck->moveCursor(QTextCursor::End);
    }
}

void handler_gui::MainWindow::on_speed_clicked()
{
    ui.StatusCheck->insertPlainText(" SPEED MODE ON!!\n");
    ui.StatusCheck->moveCursor(QTextCursor::End);
}

void handler_gui::MainWindow::on_joint_clicked()
{
    ui.StatusCheck->insertPlainText(" JOINT MODE ON!!\n");
    ui.StatusCheck->moveCursor(QTextCursor::End);
}

void MainWindow::on_Initializebutton_clicked()
{
    if(Automode == false)
    {
        if(START_KEY ==true)
        {
            if(ui.joint->isChecked())
            {
                kaist::motion INIT_MOTION;
                INIT_MOTION.motion = kaist::motion::INIT;
                gui_pub.publish(INIT_MOTION);
                ui.StatusCheck->insertPlainText(" System Initializing\n");
                ui.StatusCheck->moveCursor(QTextCursor::End);
            }
            else QMessageBox::information(this,"STOP!","Please Joint mode Check!");
        }
        else QMessageBox::information(this,"STOP!","Please START mode Check!");
    }

}

void MainWindow::on_ENDbutton_clicked()
{
    if(Automode == false)
    {
        START_KEY = false;
        if(ui.joint->isChecked())
        {
            kaist::motion END_MOTION;
            END_MOTION.motion = kaist::motion::END;
            for(int i=1;i<5;i++)
            {
                END_MOTION.id.push_back(i);
            }
            gui_pub.publish(END_MOTION);
            END_MOTION.id.clear();
            ui.StatusCheck->insertPlainText("System End!\n");
            ui.StatusCheck->moveCursor(QTextCursor::End);
        }
        else QMessageBox::information(this,"STOP!","Please Joint mode Check!");
    }
}

void MainWindow::on_TorqueOnbutton_clicked()
{
    kaist::motion TorqueOn;
    TorqueOn.motion = kaist::motion::TORQUEON;
    for(int i=1;i<5;i++)
    {
        TorqueOn.id.push_back(i);
    }

    gui_pub.publish(TorqueOn);
    TorqueOn.id.clear();

    ui.StatusCheck->insertPlainText(" Motor Torque ON\n");
    ui.StatusCheck->moveCursor(QTextCursor::End);
}

void MainWindow::on_TorqueOffbutton_clicked()
{
    kaist::motion TorqueOff;
    TorqueOff.motion = kaist::motion::TORQUEOFF;
    for(int i=1;i<5;i++)
    {
        TorqueOff.id.push_back(i);
    }

    gui_pub.publish(TorqueOff);
    TorqueOff.id.clear();
    ui.StatusCheck->insertPlainText(" Motor Torque OFF\n");
    ui.StatusCheck->moveCursor(QTextCursor::End);
}


void handler_gui::MainWindow::on_STARTbutton_clicked()
{
    if(Automode == false)
    {
        START_KEY = true;
        if(ui.joint->isChecked())
        {
            kaist::motion START_MOTION;
            START_MOTION.motion = kaist::motion::START;  
            gui_pub.publish(START_MOTION);
            ui.StatusCheck->insertPlainText(" START Uart ON !!\n");
            ui.StatusCheck->moveCursor(QTextCursor::End);
        }
        else QMessageBox::information(this,"STOP!","Please Joint mode Check!");

    }
}

void handler_gui::MainWindow::on_STOPbutton_clicked()
{
    if(Automode == false)
    {
        ui.StatusCheck->insertPlainText(" Handler stop !!\n");
        ui.StatusCheck->moveCursor(QTextCursor::End);

    }
}

void handler_gui::MainWindow::on_sendbutton_clicked()
{
    if(Automode == false)
    {
        ui.StatusCheck->insertPlainText(" SEND MSG !!\n");
        ui.StatusCheck->moveCursor(QTextCursor::End);
    }
}

//auto
void handler_gui::MainWindow::on_automode_clicked()
{
    Automode = true;
    ui.StatusCheck->insertPlainText("Auto Mode Start !!\n");
    ui.StatusCheck->moveCursor(QTextCursor::End);
}

void handler_gui::MainWindow::on_MenuMode_clicked()
{
    Automode = false;
    ui.StatusCheck->insertPlainText("Manual Mode Start !!\n");
    ui.StatusCheck->moveCursor(QTextCursor::End);
}


void handler_gui::MainWindow::on_Offsetbutton_clicked()
{
    kaist::motion CLEAR_OFFSET;
    CLEAR_OFFSET.motion = kaist::motion::OFFSET;
    for(int i=1;i<5;i++)
    {
        CLEAR_OFFSET.id.push_back(i);
    }
    gui_pub.publish(CLEAR_OFFSET);
    CLEAR_OFFSET.id.clear();

    ui.StatusCheck->insertPlainText("All OFFSET CLEAR !!\n");
    ui.StatusCheck->moveCursor(QTextCursor::End);
}

}  // namespace handler_gui


///////////////////////////////////////////////////////////////////////////////////////////////


