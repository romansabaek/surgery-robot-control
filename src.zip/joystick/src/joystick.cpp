/*==============================================================================
 *
 *   joystick.cpp
 *
 *   	File Name   	: joystick.cpp
 *  	Version        	: 1.0
 *    	Date           	: July 11, 2016 ~
 *		Author         	: BaekDongHoon
 *		work        	: joystick callback & publish data to dynamixel
 *		Compiler		: catkin
 *    	All Rights Reserved.
 *
==============================================================================*/


#include "ros/ros.h"
#include "sensor_msgs/Joy.h"

#include "kaist/dynamixel_msg.h"
#include "kaist/motion.h"
#include "kaist/gui_msg.h"
#include <vector>


#define Left            1
#define Right           2
#define Up              3
#define Down            4
#define Rotation_L      5
#define Rotation_R      6
#define STOP            7
#define Rotation_on     8
#define Translation_on  9
#define Translation_off 10
#define READ            11
#define OK              12


#define cw     1
#define ccw    2

#define MOTOR_PITCH     1
#define MOTOR_ROLL      2
#define MOTOR_TRANSLATION   3
#define MOTOR_ROTATION  4


//command
#define joint  21
#define speed  22
#define TorqueOn  23
#define EndMode   24

//MOTION
#define init_mode   30

//define parameter
double data[3] = {0,}; //axes 0,1 ,rotation on off,
int P_mot_state[4] = {0,}; // 0: up down 1: left right 2: rotate R,L
int translation_speed = 0;
bool SPEED_MODE = true ;
bool START_KEY = false;
int count, cnt =0;
int joint_result =0;
unsigned char buffer[255] = {0,};

ros::Publisher pub;


//define function//
void joy_control_speed(kaist::dynamixel_msg control,int key);
void joy_control_joint(kaist::dynamixel_msg control,int key);
double POSI_FILTER(double data);
double FILTER(double data);


//callback function///
/// filter function///

void msgjoycallback(const sensor_msgs::Joy::ConstPtr& msg)
{
    kaist::dynamixel_msg command;

    //lock button
    if(msg->buttons[0]==1)
    {
        cnt++;
        if(cnt>10) cnt =1;

        if(cnt%2==0) START_KEY = false;
        else
        {
            printf("NOW YOU can control the system\n");
            START_KEY = true;
        }
    }
    //MODE CHANGE
    else if(msg->buttons[3] == 1)
    {
        if(count%2==0) SPEED_MODE = true;
        else SPEED_MODE = false;

        if(SPEED_MODE == true)
        {
            joy_control_speed(command,speed);
        }
        else if(SPEED_MODE == false)
        {
            //joy_control_speed(command,joint);
        }

        count++;
    }

    else if(msg->buttons[5] ==1)
    {
        joy_control_speed(command,READ);
    }

    ///////////////Control///////////////
    //ROLL PITCH
    if(msg->axes[0] >= 0.3 && msg->axes[0] <= 1)
    {
        if(SPEED_MODE == true)
        {
            data[0] = msg->axes[0];
            joy_control_speed(command,Left);
        }
    }
    if(msg->axes[0] <= -0.3 && msg->axes[0] >= -1)
    {
        if(SPEED_MODE == true)
        {
            data[0] = msg->axes[0];
            joy_control_speed(command,Right);
        }
    }
    if(msg->axes[1] >= 0.3 && msg->axes[1] <= 1)
    {
        if(SPEED_MODE == true)
        {
            data[1] = msg->axes[1];
            joy_control_speed(command,Up);
        }
    }
    if(msg->axes[1] <= -0.3 && msg->axes[1] >= -1)
    {
        if(SPEED_MODE == true)
        {
            data[1] = msg->axes[1];
            joy_control_speed(command,Down);
        }
    }

    //ROTATION
    if(msg->axes[3] <= -0.3 && msg->axes[3] >= -1)
    {
        if(SPEED_MODE == true)
        {
            data[2] = msg->axes[3];
            joy_control_speed(command,Rotation_R);
        }
    }

    if(msg->axes[3] <=1 && msg->axes[3] >= 0.3)
    {
        if(SPEED_MODE == true)
        {
            data[2] = msg->axes[3];
            joy_control_speed(command,Rotation_L);
        }
    }


    //TRANSLATION
    if(msg->axes[6] == 1) //--
    {
        if(SPEED_MODE == true)
        {
            data[3] = msg->axes[6];
	    ROS_INFO("Transe on");
            joy_control_speed(command,Translation_on);
        }
    }

    if(msg->axes[6] == -1)  //++
    {
         if(SPEED_MODE == true)
        {
            data[3] = msg->axes[6];
            ROS_INFO("Transe off");
            joy_control_speed(command,Translation_off);
        }
    }

    //STOP
    else if((msg->axes[0]>0 && msg->axes[0]<0.3) || (msg->axes[0]> -0.3 && msg->axes[0]<0)
            || (msg->axes[1]>0 && msg->axes[1]<0.3) || (msg->axes[1]> -0.3 && msg->axes[1]<0)
            || (msg->axes[3]>0 && msg->axes[3]<0.3) || (msg->axes[3]> -0.3 && msg->axes[3]<0)
            || msg->axes[5]==1 || msg->axes[5]==-1)
        {
            if(SPEED_MODE == true) joy_control_speed(command,STOP);

        }



}


///////joy callback function////////////////////////////////////
/////speed///////////

void joy_control_speed(kaist::dynamixel_msg control,int key)
{

    if(START_KEY == true)
    {
        //mode change
        if(key == speed)
        {
            control.mode = kaist::dynamixel_msg::DX_SPEED;
            control.command = speed;
            for(int i =1 ;i<5;i++) control.id.push_back(i);
            control.key = key;
            printf("speed mode\n");
            pub.publish(control);
            control.id.clear();
        }
//        else if(key == joint)
//        {
//            control.mode = kaist::dynamixel_msg::DX_JOINT;
//            control.command = joint;
//            for(int i =1 ;i<5;i++) control.id.push_back(i);
//            control.key = key;
//            printf("joint mode\n");
//            pub.publish(control);
//            control.id.clear();
//        }
        else if(key == READ)
        {
            control.mode = kaist::dynamixel_msg::DX_READ;
            control.command = speed;
            for(int i =1 ;i<5;i++) control.id.push_back(i);
            control.key = key;
            printf("READ mode\n");
            pub.publish(control);
            control.id.clear();
        }

        //ROLL PITCH
        else if(key == Left || key == Right)
        {
            //save msg data
            control.mode = kaist::dynamixel_msg::DX_LEFT_RIGHT;
            control.command = speed;
            control.id.push_back(MOTOR_ROLL);
            control.key = key;

            if(key == Left)
            {
                printf("left control moving speed = %f\n",data[0]*20);
                P_mot_state[1] = cw;
                control.Moving_speed.push_back(1024+data[0]*20);
            }
            else if(key ==Right)
            {
                printf("right control moving speed = %f\n",data[0]*20);
                P_mot_state[1] = ccw;
                control.Moving_speed.push_back(-data[0]*20);
            }

            pub.publish(control);
            control.id.clear();
            control.Moving_speed.clear();
        }
        else if(key == Up || key == Down)
        {
            //save msg data
            control.mode = kaist::dynamixel_msg::DX_UP_DOWN;
            control.command = speed;
            control.id.push_back(MOTOR_PITCH);
            control.key = key;

            if(key == Up)
            {
                printf("up control moving speed = %f\n",data[1]*20);
                P_mot_state[0] = cw;
                control.Moving_speed.push_back(1024+data[1]*20);//data[1]*
            }
            else
            {
                printf("down control moving speed = %f\n",data[1]*20);
                P_mot_state[0] = ccw;
                control.Moving_speed.push_back(-data[1]*20);//data[1]*
            }

            pub.publish(control);
            control.id.clear();
            control.Moving_speed.clear();
        }

        //ROTATION//
        else if(key == Rotation_L || key == Rotation_R)
        {
            control.mode = kaist::dynamixel_msg::DX_ROTATION_L_R;
            control.command = speed;
            control.id.push_back(MOTOR_ROTATION);
            control.key = key;

            if(key == Rotation_L)
            {
                printf("Rotation Left moving speed = %f\n",data[2]*200);
                P_mot_state[2] = ccw;
                control.Moving_speed.push_back(data[2]*200);

            }
            else
            {
                printf("Rotation Right moving speed = %f\n",data[2]*200);
                P_mot_state[2] = cw;
                control.Moving_speed.push_back(1024-data[2]*200);

            }

            pub.publish(control);
            control.id.clear();
            control.Moving_speed.clear();
        }

        //TRANSLATION//
        else if(key == Translation_on)
        {
            control.mode = kaist::dynamixel_msg::DX_TRANSLATION_ON;
            control.command = speed;
            control.id.push_back(MOTOR_TRANSLATION);
            control.key = key;
	    control.toward = ccw;
            P_mot_state[3] = ccw;
            control.Moving_speed.push_back(data[3]*200);
            printf("%f\n",data[3]*200);
            
            pub.publish(control);
            control.id.clear();
            control.Moving_speed.clear();
        }
        else if(key == Translation_off)
        {
            control.mode = kaist::dynamixel_msg::DX_TRANSLATION_OFF;
            control.command = speed;
            control.id.push_back(MOTOR_TRANSLATION);
            control.key = key;
	    control.toward = cw;
            P_mot_state[3] = cw;
            control.Moving_speed.push_back(1024-data[3]*200);
            printf("%f\n",1024-data[3]*200);
            pub.publish(control);
            control.id.clear();
            control.Moving_speed.clear();
        }


        //stop
        else if(key == STOP)
        {
            control.mode = kaist::dynamixel_msg::DX_STOP;
            control.command = speed;
            for(int id=1;id<5;id++) control.id.push_back(id); //ID 1~4
            control.key = key;

            for(int i=0;i<4;i++)
            {
                if(P_mot_state[i] == ccw) control.Moving_speed.push_back(0);
                else if(P_mot_state[i] == cw) control.Moving_speed.push_back(1024);
            }
            pub.publish(control);
            control.id.clear();
            control.Moving_speed.clear();
        }



    }
    else printf("lock\n Please turn on the button\n");

}





//filter
double POSI_FILTER(double data)
{
    if((data >= -1 && data <-0.9)  ||  (data >=0.9 && data <=1))  data = 300;
    else if((data >= -0.9 && data <-0.8)  ||  (data >=0.8 && data <0.9)) data = 200;
    else if((data >= -0.8 && data <-0.7)  ||  (data >=0.7 && data <0.8)) data = 200;
    else if((data >= -0.7 && data <-0.6)  ||  (data >=0.6 && data <0.7)) data = 100;
    else if((data >= -0.6 && data <-0.5)  ||  (data >=0.5 && data <0.6)) data = 100;
    else if((data >= -0.5 && data <-0.4)  ||  (data >=0.4 && data <0.5)) data = 50;
    else if((data >= -0.4 && data <=-0.3) ||  (data >=0.4 && data <0.5)) data = 50;
    return data;
}


double FILTER(double data)
{
    if((data >= -1 && data <-0.9)  ||  (data >=0.9 && data <=1))  data = 60;
    else if((data >= -0.9 && data <-0.8)  ||  (data >=0.8 && data <0.9)) data = 50;
    else if((data >= -0.8 && data <-0.7)  ||  (data >=0.7 && data <0.8)) data = 40;
    else if((data >= -0.7 && data <-0.6)  ||  (data >=0.6 && data <0.7)) data = 30;
    else if((data >= -0.6 && data <-0.5)  ||  (data >=0.5 && data <0.6)) data = 20;
    else if((data >= -0.5 && data <-0.4)  ||  (data >=0.4 && data <0.5)) data = 10;
    else if((data >= -0.4 && data <=-0.3) ||  (data >=0.4 && data <0.5)) data = 5;
    return data;

    return data;
}
///////////////MAIN//////

int main(int argc, char **argv)
{
    ros::init(argc, argv, "joystick");
    ros::NodeHandle nh;

    ros::Subscriber sub = nh.subscribe("joy",10,msgjoycallback);

    pub = nh.advertise<kaist::dynamixel_msg>("dynamixel",100);

    ros::Rate loop_rate(1000);

    ros::spin();
    return 0;
}
