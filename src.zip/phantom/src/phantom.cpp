/*==============================================================================
 *
 *   phantom.cpp
 *
 *   	File Name   	: phantom.cpp
 *  	Version        	: 1.0
 *    	Date           	: July 11, 2016 ~
 *		Author         	: BaekDongHoon
 *		work        	: phantom callback & publish data to dynamixel
 *		Compiler		: catkin
 *    	All Rights Reserved.
 *
==============================================================================*/



#include <ros/ros.h>
#include <sensor_msgs/JointState.h>
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <assert.h>
#include <sstream>
#include <pthread.h>
#include <vector>

#include <HL/hl.h>
#include <HD/hd.h>
#include <HDU/hduError.h>
#include <HDU/hduVector.h>
#include <HDU/hduMatrix.h>

#include "phantom_omni/PhantomButtonEvent.h"
#include "phantom_omni/OmniFeedback.h"
#include "kaist/dynamixel_msg.h"
#include "kaist/motion.h"
#include "kaist/gui_msg.h"


#define Left            1
#define Right           2
#define Up              3
#define Down            4
#define Rotation_L      5
#define Rotation_R      6
#define STOP            7
#define Rotation_on     8
#define Translation_on  9
#define Translation_off 10
#define READ            11
#define OK              12


#define cw     1
#define ccw    2

#define MOTOR_PITCH     1
#define MOTOR_ROLL      2
#define MOTOR_TRANSLATION   3
#define MOTOR_ROTATION  4
#define speed_value 2000

//command
#define joint  21
#define speed  22
#define TorqueOn  23
#define EndMode   24


ros::Publisher pub;
void msgButtoncallback(const phantom_omni::PhantomButtonEvent::ConstPtr& msg);
void msgPHANToMcallback(const sensor_msgs::JointState::ConstPtr& msg);
void PHANTOM_control_speed(kaist::dynamixel_msg control,int key);


//parameter
bool start_button, Rotate_button = false;
double Cur_POSI[4] = {0.0f,};
double Old_POSI[4] = {0.0f,};
double Err_POSI[4] = {0.0f,};
int P_mot_state[4] = {0,};

///////////////MAIN//////

int main(int argc, char **argv)
{
    ros::init(argc, argv, "Geomagic_Touch_node");
    ros::NodeHandle nh;

    ros::Subscriber sub = nh.subscribe("omni1_joint_states",10,msgPHANToMcallback);
    ros::Subscriber sub_button =  nh.subscribe("omni1_button",10,msgButtoncallback);

    pub = nh.advertise<kaist::dynamixel_msg>("dynamixel",100);

    ros::Rate loop_rate(10000);

    ros::spin();
    return 0;
}

void msgPHANToMcallback(const sensor_msgs::JointState::ConstPtr& msg)
{
    kaist::dynamixel_msg command;
    	
    Cur_POSI[0] = msg->position[0]; //roll
    Cur_POSI[1] = msg->position[1]; //pitch
    Cur_POSI[2] = msg->position[5]; //rotation
    Cur_POSI[3] = msg->position[5];

    for(int i=0;i<4;i++) Err_POSI[i] = Cur_POSI[i] - Old_POSI[i];

    for(int i=0;i<4;i++) Old_POSI[i] = Cur_POSI[i];
    //printf("Yaw : %f,  Pitch : %f,  Rot : %f",Err_POSI[0],Err_POSI[1],Err_POSI[2]);

    if(Err_POSI[0]>0.0) PHANTOM_control_speed(command,Right);
    else if(Err_POSI[0]<0.0) PHANTOM_control_speed(command,Left);

    if(Err_POSI[1]>0.0) PHANTOM_control_speed(command,Up);
    else if(Err_POSI[1]<0.0) PHANTOM_control_speed(command,Down);

    if(Err_POSI[2]>0) PHANTOM_control_speed(command,Rotation_R);
    else if(Err_POSI[2]<0) PHANTOM_control_speed(command,Rotation_L);

    if(Err_POSI[3]>0) PHANTOM_control_speed(command,Translation_on);
    else if(Err_POSI[3]<0) PHANTOM_control_speed(command,Translation_off);
	
}



void msgButtoncallback(const phantom_omni::PhantomButtonEvent::ConstPtr& msg)
{
    kaist::dynamixel_msg command;
    if(msg->grey_button ==1)
    {
        ROS_INFO("START BUTTON PRESS!");
        start_button = true;
    }
    else if(msg->grey_button ==0)
    {
        ROS_INFO("STOP BUTTON PRESS!");
        PHANTOM_control_speed(command,STOP);
        start_button = false;
    }

    //white button
    if(msg->white_button ==1)
    {
	ROS_INFO("WHITE");
        Rotate_button = true;
    }
    else if(msg->white_button ==0)
    {
        PHANTOM_control_speed(command,STOP);
        Rotate_button = false;
    }
}


void PHANTOM_control_speed(kaist::dynamixel_msg control,int key)
{
    if(start_button == true)
    {
        if(key == Left || key == Right)
        {
            //save msg data
            control.mode = kaist::dynamixel_msg::DX_LEFT_RIGHT;
            control.command = speed;
            control.id.push_back(MOTOR_ROLL);
            control.key = key;

            if(key == Left)
            {
                printf("left control moving speed = %f\n",-Err_POSI[0]*speed_value);
                P_mot_state[1] = cw;
                control.Moving_speed.push_back(-Err_POSI[0]*speed_value);
            }
            else if(key ==Right)
            {
                printf("right control moving speed = %f\n",1024+Err_POSI[0]*speed_value);
                P_mot_state[1] = ccw;
                control.Moving_speed.push_back(1024+Err_POSI[0]*speed_value);
            }

            pub.publish(control);
            control.id.clear();
            control.Moving_speed.clear();
        }
        else if(key == Up || key == Down)
        {
            //save msg data
            control.mode = kaist::dynamixel_msg::DX_UP_DOWN;
            control.command = speed;
            control.id.push_back(MOTOR_PITCH);
            control.key = key;

            if(key == Up)
            {
                printf("up control moving speed = %f\n",Err_POSI[1]*speed_value);
                P_mot_state[0] = cw;
                control.Moving_speed.push_back(1024+Err_POSI[1]*speed_value);
            }
            else
            {
                printf("down control moving speed = %f\n",Err_POSI[1]*speed_value);
                P_mot_state[0] = ccw;
                control.Moving_speed.push_back(-Err_POSI[1]*speed_value);
            }

            pub.publish(control);
            control.id.clear();
            control.Moving_speed.clear();
        }
	
	//TRANSLATION//
        else if(key == Translation_on)
        {
            control.mode = kaist::dynamixel_msg::DX_TRANSLATION_ON;
 	    control.command = speed;            
	    control.id.push_back(MOTOR_TRANSLATION);
            control.key = key;
            P_mot_state[3] = ccw;
            control.Moving_speed.push_back(Err_POSI[2]*speed_value*10);
	    //printf("%f\n",data[3]*200);
            
	    pub.publish(control);
            control.id.clear();
            control.Moving_speed.clear();
        }
        else if(key == Translation_off)
        {
            control.mode = kaist::dynamixel_msg::DX_TRANSLATION_OFF;
	    control.command = speed;
            control.id.push_back(MOTOR_TRANSLATION);
            control.key = key;
            P_mot_state[3] = cw;
            control.Moving_speed.push_back(1024-Err_POSI[2]*speed_value*10);
	    //printf("%f\n",1024-data[3]*200);
            pub.publish(control);
            control.id.clear();
            control.Moving_speed.clear();
        }
	
        else if(key == STOP)
        {
            control.mode = kaist::dynamixel_msg::DX_STOP;
            control.command = speed;
            for(int id=1;id<5;id++) control.id.push_back(id); //ID 1~4
            control.key = key;

            for(int i=0;i<4;i++)
            {
                if(P_mot_state[i] == ccw) control.Moving_speed.push_back(0);
                else if(P_mot_state[i] == cw) control.Moving_speed.push_back(1024);
            }
            pub.publish(control);
            control.id.clear();
            control.Moving_speed.clear();
        }
    }

    if(Rotate_button ==true)
    {
    	if(key == Rotation_L || key == Rotation_R)
        {
	    
        control.mode = kaist::dynamixel_msg::DX_ROTATION_L_R;
        control.command = speed;
        control.id.push_back(MOTOR_ROTATION);
        control.key = key;

        if(key == Rotation_L)
    	{
            printf("Rotation Left moving speed = %f\n",Err_POSI[2]*speed_value*10);
            P_mot_state[2] = cw;
            control.Moving_speed.push_back(-Err_POSI[2]*speed_value*10);
        }
        else
        {
	        printf("Rotation Right moving speed = %f\n",1024-Err_POSI[2]*speed_value*10);
  	        P_mot_state[2] = ccw;
            control.Moving_speed.push_back(1024+Err_POSI[2]*speed_value*10);
        }
        pub.publish(control);
        control.id.clear();
        control.Moving_speed.clear();	    
        }
	
        else if(key == STOP)
        {
            control.mode = kaist::dynamixel_msg::DX_STOP;
            control.command = speed;
            for(int id=1;id<5;id++) control.id.push_back(id); //ID 1~4
            control.key = key;

            for(int i=0;i<4;i++)
            {
                if(P_mot_state[i] == ccw) control.Moving_speed.push_back(0);
                else if(P_mot_state[i] == cw) control.Moving_speed.push_back(1024);
            }
            pub.publish(control);
            control.id.clear();
            control.Moving_speed.clear();
        }
    }
}



