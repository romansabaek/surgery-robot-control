/*==============================================================================
 *
 *   dynamixel.cpp
 *
 *   	File Name   	: kaist_dm.cpp
 *  	Version        	: 1.0
 *    	Date           	: July 11, 2016 ~
 *		Author         	: BaekDongHoon
 *		work         	: dynamixel controller
 *		Compiler		: catkin
 *    	All Rights Reserved.
 *
==============================================================================*/

#include "ros/ros.h"
#include "std_msgs/String.h"
#include <iostream>
#include <sstream>
#include <vector>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <termios.h>
#include <getopt.h>
#include <fcntl.h>
#include <math.h>

#include "../include/kaist/dynamixel.h"
#include "../include/kaist/serialport.h"
#include "../include/kaist/dx_function.h"
#include "sensor_msgs/Joy.h"
#include "std_msgs/Int32MultiArray.h"

#include "kaist/dynamixel_msg.h"
#include "kaist/motion.h"
#include "kaist/gui_msg.h"

// Control table address
#define P_CW_ANGLE_LIMIT         6
#define P_CCW_ANGLE_LIMIT        8
#define P_TORQUE_ENABLE         24
#define P_GOAL_POSITION		    30
#define P_GOAL_SPEED		    32
#define P_PRESENT_POSITION   	36
#define P_PRESENT_SPEED		    38
#define P_MOVING                46
#define P_PRESENT_JOINT         8
#define P_Multi_offset          20
#define P_Current               68

#define Left            1
#define Right           2
#define Up              3
#define Down            4
#define Rotation_L      5
#define Rotation_R      6
#define STOP            7
#define Rotation_on     8
#define Translation_on  9
#define Translation_off 10
#define READ            11
#define OK              12

#define CONTROL_PERIOD		10000 // usec (Large value is more slow)
#define PKT_RTN_DELAY_US	5000

#define MOTOR_PITCH     1
#define MOTOR_ROLL      2
#define MOTOR_TRANSLATION   3
#define MOTOR_ROTATION  4

//command
#define joint  21
#define speed  22

#define key_OFFSET 23

//function
void DX_dynamixel_callback(const kaist::dynamixel_msg::ConstPtr& msg);
void DX_motion_callback(const kaist::motion::ConstPtr& msg);
void Syncwrite_Packet(int command);
void gui_pub(kaist::gui_msg data,int key,int SPEED,int ID, int POSI, float Cur);
void DX_voice_callback(const std_msgs::Int32MultiArray::ConstPtr& msg);


ros::Publisher gui_read_pub;
ros::Subscriber dx_sub;
ros::Subscriber dx_motion_sub;
ros::Subscriber dx_voice_sub;

//parameter
int moving_speed[4] = {0,};
int moving_position[4] = {0,};
int P_OFFSET[] ={0,};
int P_posi[] = {0,};
int p_speed[] = {0,};
float P_current[] = {0,};
int stop_bit[3] ={0,};
using namespace std;

//main
int main(int argc, char **argv)
{
    ros::init(argc, argv, "kaist_dynamixel");
    ros::NodeHandle nh;


    dx_sub = nh.subscribe("dynamixel", 100, DX_dynamixel_callback);
    dx_motion_sub = nh.subscribe("motion",100,DX_motion_callback);
    dx_voice_sub = nh.subscribe("voice",100,DX_voice_callback);
    gui_read_pub = nh.advertise<kaist::gui_msg>("gui",100);


    if (MOT_InitUART() == 0)
    {
        printf("ERROR : InitUART\n");
        return 0;
    }
    sleep(1);

    ros::spin();

    return 0;
}


///dynamixel callback////////////  
void DX_dynamixel_callback(const kaist::dynamixel_msg::ConstPtr& msg)
{

    kaist::gui_msg gui_data;
    switch(msg->mode)
    {
        //read
        case kaist::dynamixel_msg::DX_READ:

        for(int i=0; i<msg->id.size(); i++ )
        {
            printf("READ MODE id= %d  data = %d\n",msg->id[i],dxl_read_word(msg->id[i],P_PRESENT_POSITION));
            usleep(PKT_RTN_DELAY_US);
        }
        break;

        //change mode
        case kaist::dynamixel_msg::DX_SPEED:

        for(int i=0; i<msg->id.size(); i++ )
        {
            ROS_INFO("SPEED MODE id= %d ",msg->id[i]);
            dxl_write_word(msg->id[i],P_CW_ANGLE_LIMIT,0);
            dxl_write_word(msg->id[i],P_CCW_ANGLE_LIMIT,0);
            //dxl_write_word(msg->id[i],P_TORQUE_ENABLE,1);
            usleep(PKT_RTN_DELAY_US);
        }
        break;

        case kaist::dynamixel_msg::DX_JOINT:

        for(int i=0; i<msg->id.size(); i++ )
        {
            ROS_INFO("JOINT MODE id = %d ",msg->id[i]);
            dxl_write_word(msg->id[i],P_CW_ANGLE_LIMIT,0);
            dxl_write_word(msg->id[i],P_CCW_ANGLE_LIMIT,4095);
            //dxl_write_word(msg->id[i],P_TORQUE_ENABLE,1);
            usleep(PKT_RTN_DELAY_US);
        }
        break;

        //up down
        case kaist::dynamixel_msg::DX_UP_DOWN:

        if(msg->command == speed)
        {
            for(int i=0; i<msg->id.size(); i++ )
            {
                moving_speed[i] = int(msg->Moving_speed[i]);
                if(msg->key == Down) ROS_INFO("DX DOWN OK!  id = %d speed = %d",msg->id[i],moving_speed[i]);
                else if(msg->key == Up) ROS_INFO("DX UP OK!  id = %d speed = %d",msg->id[i],moving_speed[i]);



                if( dxl_read_word(msg->id[i],P_PRESENT_POSITION) >= 1600 && dxl_read_word(msg->id[i],P_PRESENT_POSITION) <= 2500)
                {
                    dxl_write_word(msg->id[i],P_GOAL_SPEED,moving_speed[i]);
                    usleep(PKT_RTN_DELAY_US);
                    p_speed[i] = dxl_read_word(msg->id[i],P_PRESENT_SPEED);
                    P_posi[i] = dxl_read_word(msg->id[i],P_PRESENT_POSITION);
                    P_current[i] = 0.001*4.5 * (dxl_read_word(msg->id[i],P_Current) - 2048);
                    printf("current = %f \n",P_current[i]);
                    gui_pub(gui_data,msg->key,p_speed[i],msg->id[i],P_posi[i],P_current[i]);

                }

                else
                {
                    printf("over position\n");
                    if(msg->key == Up || msg->key == Left || msg->key ==Rotation_L) dxl_write_word(msg->id[i],P_GOAL_SPEED,1024);
                    else if(msg->key == Down || msg->key == Right || msg->key ==Rotation_R) dxl_write_word(msg->id[i],P_GOAL_SPEED,0);
                    usleep(PKT_RTN_DELAY_US);

                    if(dxl_read_word(msg->id[i],P_PRESENT_POSITION) < 1600)
                    {
                        if(msg->command == speed && msg->key == Down)
                        {
                            dxl_write_word(msg->id[i],P_GOAL_SPEED,moving_speed[i]);
                            p_speed[i] = dxl_read_word(msg->id[i],P_PRESENT_SPEED);
                            P_posi[i] = dxl_read_word(msg->id[i],P_PRESENT_POSITION);
                            P_current[i] = 0.001*4.5 * (dxl_read_word(msg->id[i],P_Current) - 2048);
                            printf("current = %f \n",P_current[i]);
                            gui_pub(gui_data,msg->key,p_speed[i],msg->id[i],P_posi[i],P_current[i]);
                        }

                    }
                    else if(dxl_read_word(msg->id[i],P_PRESENT_POSITION) > 2500)
                    {
                        if(msg->command == speed && msg->key == Up)
                        {
                            dxl_write_word(msg->id[i],P_GOAL_SPEED,moving_speed[i]);
                            p_speed[i] = dxl_read_word(msg->id[i],P_PRESENT_SPEED);
                            P_posi[i] = dxl_read_word(msg->id[i],P_PRESENT_POSITION);
                            P_current[i] = 0.001*4.5 * (dxl_read_word(msg->id[i],P_Current) - 2048);
                            printf("current = %f \n",P_current[i]);
                            gui_pub(gui_data,msg->key,p_speed[i],msg->id[i],P_posi[i],P_current[i]);
                        }
                    }
                }
            }
        }
        break;




        //left right
        case kaist::dynamixel_msg::DX_LEFT_RIGHT:

        if(msg->command == speed)
        {
            for(int i=0; i<msg->id.size(); i++ )
            {
                moving_speed[i] = int(msg->Moving_speed[i]);
                if(msg->key == Left) ROS_INFO("DX LEFT OK!  id = %d speed = %d",msg->id[i],moving_speed[i]);
                else if(msg->key == Right) ROS_INFO("DX RIGHT UP OK!  id = %d speed = %d",msg->id[i],moving_speed[i]);

                if( dxl_read_word(msg->id[i],P_PRESENT_POSITION) >= 1850 && dxl_read_word(msg->id[i],P_PRESENT_POSITION) <= 2800)
                {          
                        dxl_write_word(msg->id[i],P_GOAL_SPEED,moving_speed[i]);
                        p_speed[i] = dxl_read_word(msg->id[i],P_PRESENT_SPEED);
                        printf("speed = %d\n",p_speed[i]);
                        P_posi[i] = dxl_read_word(msg->id[i],P_PRESENT_POSITION);
                        P_current[i] = 0.001*4.5 * (dxl_read_word(msg->id[i],P_Current) - 2048);
                        printf("current = %f \n",P_current[i]);
                        gui_pub(gui_data,msg->key,p_speed[i],msg->id[i],P_posi[i],P_current[i]);
                }

                else
                {
                    printf("over position\n");
                    if(msg->key == Up || msg->key == Left || msg->key ==Rotation_L) dxl_write_word(msg->id[i],P_GOAL_SPEED,1024);
                    else if(msg->key == Down || msg->key == Right || msg->key ==Rotation_R) dxl_write_word(msg->id[i],P_GOAL_SPEED,0);
                    usleep(PKT_RTN_DELAY_US);


                    if(dxl_read_word(msg->id[i],P_PRESENT_POSITION) < 2800)
                    {
                        if(msg->command == speed && msg->key == Right)
                        {                           
                                dxl_write_word(msg->id[i],P_GOAL_SPEED,moving_speed[i]);
                                p_speed[i] = dxl_read_word(msg->id[i],P_PRESENT_SPEED);
                                printf("speed = %d\n",p_speed[i]);
                                P_posi[i] = dxl_read_word(msg->id[i],P_PRESENT_POSITION);
                                P_current[i] = 0.001*4.5 * (dxl_read_word(msg->id[i],P_Current) - 2048);
                                printf("current = %f \n",P_current[i]);
                                gui_pub(gui_data,msg->key,p_speed[i],msg->id[i],P_posi[i],P_current[i]);
                        }

                    }
                    else if(dxl_read_word(msg->id[i],P_PRESENT_POSITION) > 1850)
                    {
                        if(msg->command == speed && msg->key == Left)
                        {
                                dxl_write_word(msg->id[i],P_GOAL_SPEED,moving_speed[i]);
                                p_speed[i] = dxl_read_word(msg->id[i],P_PRESENT_SPEED);
                                printf("speed = %d\n",p_speed[i]);
                                P_posi[i] = dxl_read_word(msg->id[i],P_PRESENT_POSITION);
                                P_current[i] = 0.001*4.5 * (dxl_read_word(msg->id[i],P_Current) - 2048);
                                printf("current = %f \n",P_current[i]);
                                gui_pub(gui_data,msg->key,p_speed[i],msg->id[i],P_posi[i],P_current[i]);
                        }
                    }

                }
            }
        }
        break;


        //rotation
        case kaist::dynamixel_msg::DX_ROTATION_L_R:

        if(msg->command == speed)
        {
            for(int i=0; i<msg->id.size(); i++ )
            {
                moving_speed[i] = int(msg->Moving_speed[i]);
                if(msg->key == Rotation_L) ROS_INFO("DX Rotation Left OK!  id = %d speed = %d",msg->id[i],moving_speed[i]);
                else if(msg->key == Rotation_R) ROS_INFO("DX Rotation Right OK!  id = %d speed = %d",msg->id[i],moving_speed[i]);

                dxl_write_word(msg->id[i],P_GOAL_SPEED,moving_speed[i]);
                usleep(PKT_RTN_DELAY_US);
                p_speed[i] = dxl_read_word(msg->id[i],P_PRESENT_SPEED);
                P_posi[i] = dxl_read_word(msg->id[i],P_PRESENT_POSITION);
                P_current[i] = 0.001*4.5 * (dxl_read_word(msg->id[i],P_Current) - 2048);
                gui_pub(gui_data,msg->key,p_speed[i],msg->id[i],P_posi[i],P_current[i]);
            }
        }
        break;

        //translation
        case kaist::dynamixel_msg::DX_TRANSLATION_ON: //3250 ~ 0 ~ 4000

        if(msg->command == speed)
        {
            for(int i=0; i<msg->id.size(); i++ )
            {
                moving_speed[i] = int(msg->Moving_speed[i]);
                ROS_INFO("DX TRANSLATION ON! id =%d speed = %d",msg->id[i],moving_speed[i]);

                if( dxl_read_word(msg->id[i],P_PRESENT_POSITION) >= 0 && dxl_read_word(msg->id[i],P_PRESENT_POSITION) <= 4000)
                {
                    dxl_write_word(msg->id[i],P_GOAL_SPEED,moving_speed[i]);
                    usleep(PKT_RTN_DELAY_US);
                    p_speed[i] = dxl_read_word(msg->id[i],P_PRESENT_SPEED);
                    P_posi[i] = dxl_read_word(msg->id[i],P_PRESENT_POSITION);
                    P_current[i] = 0.001*4.5 * (dxl_read_word(msg->id[i],P_Current) - 2048);
                    printf("current = %f \n",P_current[i]);
                    gui_pub(gui_data,msg->key,p_speed[i],msg->id[i],P_posi[i],P_current[i]);

                }

                else
                {
                    printf("over position\n");
                    if(msg->key == Up || msg->key == Left || msg->key ==Rotation_L || msg->key == Translation_on) dxl_write_word(msg->id[i],P_GOAL_SPEED,1024);
                    else if(msg->key == Down || msg->key == Right || msg->key ==Rotation_R || msg->key == Translation_off) dxl_write_word(msg->id[i],P_GOAL_SPEED,0);
                    usleep(PKT_RTN_DELAY_US);


                    if(dxl_read_word(msg->id[i],P_PRESENT_POSITION) > 4000)
                    {
                        if(msg->command == speed && msg->key == Translation_off)
                        {
                                dxl_write_word(msg->id[i],P_GOAL_SPEED,moving_speed[i]);
                                p_speed[i] = dxl_read_word(msg->id[i],P_PRESENT_SPEED);
                                printf("speed = %d\n",p_speed[i]);
                                P_posi[i] = dxl_read_word(msg->id[i],P_PRESENT_POSITION);
                                P_current[i] = 0.001*4.5 * (dxl_read_word(msg->id[i],P_Current) - 2048);
                                printf("current = %f \n",P_current[i]);
                                gui_pub(gui_data,msg->key,p_speed[i],msg->id[i],P_posi[i],P_current[i]);
                        }

                    }

                }

            }
        }
        break;

        case kaist::dynamixel_msg::DX_TRANSLATION_OFF:

        if(msg->command == speed)
        {
            for(int i=0; i<msg->id.size(); i++ )
            {
                moving_speed[i] = int(msg->Moving_speed[i]);
                ROS_INFO("DX TRANSLATION OFF! id =%d speed = %d",msg->id[i],moving_speed[i]);
                
 if( dxl_read_word(msg->id[i],P_PRESENT_POSITION) >= 0 && dxl_read_word(msg->id[i],P_PRESENT_POSITION) <= 4000)
                {
                    dxl_write_word(msg->id[i],P_GOAL_SPEED,moving_speed[i]);
                    usleep(PKT_RTN_DELAY_US);
                    p_speed[i] = dxl_read_word(msg->id[i],P_PRESENT_SPEED);
                    P_posi[i] = dxl_read_word(msg->id[i],P_PRESENT_POSITION);
                    P_current[i] = 0.001*4.5 * (dxl_read_word(msg->id[i],P_Current) - 2048);
                    printf("current = %f \n",P_current[i]);
                    gui_pub(gui_data,msg->key,p_speed[i],msg->id[i],P_posi[i],P_current[i]);

                }

                else
                {
                    printf("over position\n");
                    if(msg->key == Up || msg->key == Left || msg->key ==Rotation_L || msg->key == Translation_on) dxl_write_word(msg->id[i],P_GOAL_SPEED,1024);
                    else if(msg->key == Down || msg->key == Right || msg->key ==Rotation_R || msg->key == Translation_off) dxl_write_word(msg->id[i],P_GOAL_SPEED,0);
                    usleep(PKT_RTN_DELAY_US);


                    if(dxl_read_word(msg->id[i],P_PRESENT_POSITION) < 3250 )
                    {
                        if(msg->command == speed && msg->key == Translation_on)
                        {
                                dxl_write_word(msg->id[i],P_GOAL_SPEED,moving_speed[i]);
                                p_speed[i] = dxl_read_word(msg->id[i],P_PRESENT_SPEED);
                                printf("speed = %d\n",p_speed[i]);
                                P_posi[i] = dxl_read_word(msg->id[i],P_PRESENT_POSITION);
                                P_current[i] = 0.001*4.5 * (dxl_read_word(msg->id[i],P_Current) - 2048);
                                printf("current = %f \n",P_current[i]);
                                gui_pub(gui_data,msg->key,p_speed[i],msg->id[i],P_posi[i],P_current[i]);
                        }

                    }

                }

            }
        }
        break;

        //STOP
        case kaist::dynamixel_msg::DX_STOP:

        if(msg->command == speed)
        {
            for(int i=0; i<msg->id.size(); i++ )
            {
                moving_speed[i] = int(msg->Moving_speed[i]);
                ROS_INFO("DX STOP MOTOR id = %d speed = %d",msg->id[i],moving_speed[i]);
                dxl_write_word(msg->id[i],P_GOAL_SPEED,moving_speed[i]);
                usleep(PKT_RTN_DELAY_US);
                p_speed[i] = dxl_read_word(msg->id[i],P_PRESENT_SPEED);
                P_posi[i] = dxl_read_word(msg->id[i],P_PRESENT_POSITION);
                P_current[i] = 0.001*4.5 * (dxl_read_word(msg->id[i],P_Current) - 2048);
                gui_pub(gui_data,msg->key,p_speed[i],msg->id[i],P_posi[i],P_current[i]);
            }
        }
        break;
    }
}

//dynamixel motion callback
void DX_motion_callback(const kaist::motion::ConstPtr& msg)
{
        kaist::gui_msg gui_motion;

        switch (msg->motion)
        {
            //init mode
            case kaist::motion::INIT:
            ROS_INFO("init MOTION");

                dxl_write_word(2,P_GOAL_SPEED,1024+20);
                dxl_write_word(1,P_GOAL_SPEED,1024+20);
                usleep(PKT_RTN_DELAY_US);
                while(1)
                {
                    if( dxl_read_word(2,P_PRESENT_POSITION) <=2330)
                    {
                        printf("stop2 \n");
                        dxl_write_word(2,P_GOAL_SPEED,0);
                        stop_bit[0] = 1;
                    }
                    if( dxl_read_word(1,P_PRESENT_POSITION) <=2048)
                    {
                        printf("stop1 \n");
                        dxl_write_word(1,P_GOAL_SPEED,0);
                        stop_bit[1] = 1;
                    }
                    stop_bit[2] = stop_bit[0] + stop_bit[1];
                    if(stop_bit[2]==2)
                    {
                        stop_bit[0], stop_bit[1] = 0;
                        printf("out");
                        break;
                    }
                }

            break;

            //torque on
            case kaist::motion::TORQUEON:

            Syncwrite_Packet(P_TORQUE_ENABLE);
            for( int i=0; i<msg->id.size(); i++ )
            {
                dxl_set_txpacket_parameter(2+3*i, msg->id[i]);
                dxl_set_txpacket_parameter(2+3*i+1, dxl_get_lowbyte(1));
                dxl_set_txpacket_parameter(2+3*i+2, dxl_get_highbyte(1));
                usleep(CONTROL_PERIOD);
            }
            dxl_set_txpacket_length((2+1)*msg->id.size()+4);
            dxl_txrx_packet();
            break;


            //Torque off
            case kaist::motion::TORQUEOFF:

            Syncwrite_Packet(P_TORQUE_ENABLE);
            for( int i=0; i<msg->id.size(); i++ )
            {
                dxl_set_txpacket_parameter(2+3*i, msg->id[i]);
                dxl_set_txpacket_parameter(2+3*i+1, dxl_get_lowbyte(0));
                dxl_set_txpacket_parameter(2+3*i+2, dxl_get_highbyte(0));
                usleep(CONTROL_PERIOD);
            }
            dxl_set_txpacket_length((2+1)*msg->id.size()+4);
            dxl_txrx_packet();
            break;


            //STRAT
            case kaist::motion::START:
            ROS_INFO("START MOTION");

            if (MOT_InitUART() == 0)
            {
                printf("ERROR : InitUART\n");
            }
            break;

            //END
            case kaist::motion::END:

            ROS_INFO("END MOTION");

                dxl_write_word(2,P_GOAL_SPEED,20);
                dxl_write_word(1,P_GOAL_SPEED,20);
                usleep(PKT_RTN_DELAY_US);
                while(1)
                {
                    if( dxl_read_word(2,P_PRESENT_POSITION) >=2750)
                    {
                        printf("stop2 \n");
                        dxl_write_word(2,P_GOAL_SPEED,0);
                        stop_bit[0] = 1;
                    }
                    if( dxl_read_word(1,P_PRESENT_POSITION) >=2550)
                    {
                        printf("stop1 \n");
                        dxl_write_word(1,P_GOAL_SPEED,0);
                        stop_bit[1] = 1;
                    }
                    stop_bit[2] = stop_bit[0] + stop_bit[1];
                    if(stop_bit[2]==2)
                    {
                        stop_bit[0], stop_bit[1] = 0;
                        printf("out");
                        break;
                    }
                }

            Syncwrite_Packet(P_TORQUE_ENABLE);
            for( int i=0; i<msg->id.size(); i++ )
            {
                dxl_set_txpacket_parameter(2+3*i, msg->id[i]);
                dxl_set_txpacket_parameter(2+3*i+1, dxl_get_lowbyte(0));
                dxl_set_txpacket_parameter(2+3*i+2, dxl_get_highbyte(0));
                usleep(CONTROL_PERIOD);
            }
            dxl_set_txpacket_length((2+1)*msg->id.size()+4);
            dxl_txrx_packet();

            sleep(1);
            MOT_CloseUART(); //close uart
            ROS_INFO("All finish!!\n");
            break;

            //CHange mode
            case kaist::motion::CHANGEMODE:


            break;

            //OFFSET
            case kaist::motion::OFFSET:

            for(int i=0; i<msg->id.size(); i++ )
            {
                printf("key offset!\n");
                P_posi[i] = dxl_read_word(msg->id[i],P_PRESENT_POSITION);
                usleep(PKT_RTN_DELAY_US);
                p_speed[i] = dxl_read_word(msg->id[i],P_PRESENT_SPEED);
                usleep(PKT_RTN_DELAY_US);
                P_current[i] = 0.001*4.5 * (dxl_read_word(msg->id[i],P_Current) - 2048);
                gui_motion.key = key_OFFSET ;
                gui_motion.Current.push_back(P_current[i]);
                gui_motion.id.push_back(msg->id[i]);
                gui_motion.Moving_speed.push_back(p_speed[i]);
                gui_motion.Goal_position.push_back(P_posi[i]);
            }
            gui_read_pub.publish(gui_motion);
            gui_motion.id.clear();
            gui_motion.Moving_speed.clear();
            gui_motion.Goal_position.clear();
            gui_motion.Current.clear();
            break;

            default:
            break;

        }



}

void DX_voice_callback(const std_msgs::Int32MultiArray::ConstPtr& msg)
{
    if(msg->data[0]==0)
    {
        if( dxl_read_word(MOTOR_ROLL,P_PRESENT_POSITION) >= 1850 && dxl_read_word(MOTOR_ROLL,P_PRESENT_POSITION) <= 2800)
        {
                ROS_INFO("SUCCESE VOICE");
                dxl_write_word(MOTOR_ROLL,P_GOAL_SPEED,1024+20);
                //p_speed[i] = dxl_read_word(MOTOR_ROLL,P_PRESENT_SPEED);
                //printf("speed = %d\n",p_speed[i]);
                //P_posi[i] = dxl_read_word(MOTOR_ROLL,P_PRESENT_POSITION);
                //P_current[i] = 0.001*4.5 * (dxl_read_word(MOTOR_ROLL,P_Current) - 2048);
                //printf("current = %f \n",P_current[i]);
                //gui_pub(gui_data,Left,p_speed[i],MOTOR_ROLL,P_posi[i],P_current[i]);
        }

//        else
//        {
//            printf("over position\n");
//            if(msg->key == Up || msg->key == Left || msg->key ==Rotation_L) dxl_write_word(msg->id[i],P_GOAL_SPEED,1024);
//            else if(msg->key == Down || msg->key == Right || msg->key ==Rotation_R) dxl_write_word(msg->id[i],P_GOAL_SPEED,0);
//            usleep(PKT_RTN_DELAY_US);


//            if(dxl_read_word(msg->id[i],P_PRESENT_POSITION) < 2800)
//            {
//                if(msg->command == speed && msg->key == Right)
//                {
//                        dxl_write_word(msg->id[i],P_GOAL_SPEED,moving_speed[i]);
//                        p_speed[i] = dxl_read_word(msg->id[i],P_PRESENT_SPEED);
//                        printf("speed = %d\n",p_speed[i]);
//                        P_posi[i] = dxl_read_word(msg->id[i],P_PRESENT_POSITION);
//                        P_current[i] = 0.001*4.5 * (dxl_read_word(msg->id[i],P_Current) - 2048);
//            printf("current = %f \n",P_current[i]);
//                        gui_pub(gui_data,msg->key,p_speed[i],msg->id[i],P_posi[i],P_current[i]);
//                }

//            }
//            else if(dxl_read_word(msg->id[i],P_PRESENT_POSITION) > 1850)
//            {
//                if(msg->command == speed && msg->key == Left)
//                {
//                        dxl_write_word(msg->id[i],P_GOAL_SPEED,moving_speed[i]);
//                        p_speed[i] = dxl_read_word(msg->id[i],P_PRESENT_SPEED);
//                        printf("speed = %d\n",p_speed[i]);
//                        P_posi[i] = dxl_read_word(msg->id[i],P_PRESENT_POSITION);
//                        P_current[i] = 0.001*4.5 * (dxl_read_word(msg->id[i],P_Current) - 2048);
//            printf("current = %f \n",P_current[i]);
//                        gui_pub(gui_data,msg->key,p_speed[i],msg->id[i],P_posi[i],P_current[i]);
//                }
//            }


    }

}

/////dynamixel syncwrite/////
void Syncwrite_Packet(int command)
{
    dxl_set_txpacket_id(BROADCAST_ID);
    dxl_set_txpacket_instruction(INST_SYNC_WRITE);
    dxl_set_txpacket_parameter(0,command);
    dxl_set_txpacket_parameter(1, 2);
}



void gui_pub(kaist::gui_msg data, int key, int SPEED, int ID, int POSI,float Cur)
{
    data.key = key ;
    data.id.push_back(ID);
    data.Moving_speed.push_back(SPEED);
    data.Goal_position.push_back(POSI);
    data.Current.push_back(Cur);
    gui_read_pub.publish(data);
    data.id.clear();
    data.Moving_speed.clear();
    data.Goal_position.clear();
    data.Current.clear();
}













