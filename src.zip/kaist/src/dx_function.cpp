#include "ros/ros.h"
#include "std_msgs/String.h"
#include <iostream>
#include <sstream>
#include <vector>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <termios.h>
#include <getopt.h>
#include <fcntl.h>
#include <math.h>

#include "../include/kaist/dynamixel.h"
#include "../include/kaist/serialport.h"
#include "../include/kaist/dx_function.h"


// Control table address
#define P_CW_ANGLE_LIMIT         6
#define P_CCW_ANGLE_LIMIT        8
#define P_TORQUE_ENABLE         24
#define P_GOAL_POSITION		    30
#define P_GOAL_SPEED		    32
#define P_PRESENT_POSITION   	36
#define P_PRESENT_SPEED		    38
#define P_MOVING                46



#define CONTROL_PERIOD		10000 // usec (Large value is more slow)
#define PKT_RTN_DELAY_US	5000


// Value setting
#define VAL_BAUDNUM        	1	// 1M


int result = COMM_TXFAIL, error = 0;


int deviceIndex =0; //ttyUSB setting


int _getch()
{
    struct termios oldt, newt;
    int ch;
    tcgetattr( STDIN_FILENO, &oldt );
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr( STDIN_FILENO, TCSANOW, &newt );
    ch = getchar();
    tcsetattr( STDIN_FILENO, TCSANOW, &oldt );
    return ch;
}


int MOT_InitUART()
{
    // Serial Port Connection
    if( dxl_initialize(deviceIndex, VAL_BAUDNUM) == 0 )
    {
        printf("Failed to open the PORT\n");
        printf("Failed to change the baudrate!\n");
        return 0;
    }
    else
        printf("Succeed to open the PORT\n");
        printf("Succeed to change the baudrate!\n");

    return 1;
}

void MOT_CloseUART()
{
    dxl_hal_close();
}



// Print communication result
void PrintCommStatus(int CommStatus)
{
    switch(CommStatus)
    {
    case COMM_TXFAIL:
        printf("COMM_TXFAIL: Failed transmit instruction packet!\n");
        break;

    case COMM_TXERROR:
        printf("COMM_TXERROR: Incorrect instruction packet!\n");
        break;

    case COMM_RXFAIL:
        printf("COMM_RXFAIL: Failed get status packet from device!\n");
        break;

    case COMM_RXWAITING:
        printf("COMM_RXWAITING: Now recieving status packet!\n");
        break;

    case COMM_RXTIMEOUT:
        printf("COMM_RXTIMEOUT: There is no status packet!\n");
        break;

    case COMM_RXCORRUPT:
        printf("COMM_RXCORRUPT: Incorrect status packet!\n");
        break;

    default:
        printf("This is unknown error code!\n");
        break;
    }
}

void PrintErrorCode(int ErrorCode)
{
    if(ErrorCode & ERRBIT_VOLTAGE)
        printf("Input voltage error!\n");

    if(ErrorCode & ERRBIT_ANGLE)
        printf("Angle limit error!\n");

    if(ErrorCode & ERRBIT_OVERHEAT)
        printf("Overheat error!\n");

    if(ErrorCode & ERRBIT_RANGE)
        printf("Out of range error!\n");

    if(ErrorCode & ERRBIT_CHECKSUM)
        printf("Checksum error!\n");

    if(ErrorCode & ERRBIT_OVERLOAD)
        printf("Overload error!\n");

    if(ErrorCode & ERRBIT_INSTRUCTION)
        printf("Instruction code error!\n");
}
















