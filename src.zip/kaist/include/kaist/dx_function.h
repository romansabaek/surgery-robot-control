int _getch();
int MOT_InitUART();
void MOT_CloseUART();
void PrintCommStatus(int CommStatus);
void PrintErrorCode(int ErrorCode);
